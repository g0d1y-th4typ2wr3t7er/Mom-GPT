# Mom GPT Assistant (prototype)

A native Android starter project for a Vivo Y200 5G / Android 15. It includes:
- A floating edge button (Android overlay permission required).
- A basic chat screen.
- Android speech-to-text using the phone's speech recognition service.
- Spoken answers using Android TextToSpeech.
- Direct OpenAI Responses API calls from the phone (no separate server).

## Important limitations
This is a **source project**, not a compiled or device-tested APK. It has not been built in this environment because the Android SDK/Gradle build tools are not installed here. Open it in Android Studio, let Gradle sync, then build and test on a real phone before relying on it.

The app asks for an OpenAI API key and stores it in the app's private preferences. That is convenient for a personal prototype but **not secure against someone who can inspect/compromise the phone**. Do not distribute this APK to other people with a private key embedded in it. OpenAI API usage is billed separately from a ChatGPT subscription. Create/manage API keys and billing only with an adult's permission.

## Build on your ASUS VivoBook
1. Install Android Studio from the official Android developer site.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `MomGPTAssistant` folder.
4. Let Gradle sync. Install Android SDK Platform 35 if Android Studio asks.
5. Use **Build > Build APK(s)**.
6. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## First run on the Vivo
1. Install the APK and open **Mom GPT**.
2. Tap **Set API key** and enter an OpenAI API key. API use costs money; confirm billing/limits with a parent first.
3. Tap **Enable floating button**.
4. Android settings opens. Allow **Display over other apps** for Mom GPT.
5. Return to the app and tap **Enable floating button** again.
6. Tap **Speak**, grant microphone permission, speak, and wait for the spoken answer.
7. Tap the floating GPT bubble from another app to reopen Mom GPT.

## Notes
- This prototype uses the phone's built-in speech recognition for input and Android TTS for output. It is turn-based, not continuous full-duplex live voice.
- The API model name is set to `gpt-4.1-mini` in `OpenAiClient.kt`; change it only to a model available to the API project.
- For a production-quality app, move API authentication to a secure backend or use an approved short-lived client-token flow. Avoid putting long-lived API secrets in an APK.


## Build in the cloud (no Android Studio on your PC)
1. Sign in to GitHub and create a new repository. For the easiest first attempt, choose **Private**.
2. Upload the contents of this project folder to the repository root (not the ZIP file itself). Make sure `.github/workflows/build-apk.yml` is included. GitHub's web uploader may hide dot-folders; if it does, use GitHub's web editor to create the workflow file at that exact path.
3. Open the repository's **Actions** tab. Select **Build Mom GPT APK**, then click **Run workflow** if it has not already started after the upload.
4. Open the completed workflow run. Under **Artifacts**, download `MomGPT-debug-apk`.
5. Extract the artifact ZIP; it contains `app-debug.apk`.

The cloud build is not a guarantee the prototype compiles; if it fails, open the workflow run and inspect the build log. Do not upload an OpenAI API key to GitHub. This app asks for the key on the phone.
