package com.example.momgpt

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var speechReady = false
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("mom_gpt", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(16))
            setBackgroundColor(Color.rgb(10, 16, 30))
        }
        val title = TextView(this).apply {
            text = "Mom GPT"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Tap, speak, and get help."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(12))
        }
        status = TextView(this).apply {
            text = "Add an OpenAI API key in Settings to connect GPT."
            textSize = 13f
            setTextColor(Color.rgb(170, 190, 255))
            setPadding(0, 0, 0, dp(10))
        }
        transcript = TextView(this).apply {
            text = "Hello! I can help you practise English or answer everyday questions."
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(27, 39, 61))
        }
        val scroll = ScrollView(this).apply {
            addView(transcript)
        }
        input = EditText(this).apply {
            hint = "Type a message (optional)"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setSingleLine(false)
            minLines = 1
            maxLines = 3
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(27, 39, 61))
        }
        val send = button("Send") { sendTypedMessage() }
        val speak = button("Speak") { startSpeechRecognition() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(speak, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
            addView(send, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        }
        val keyButton = button("Set API key") { setApiKey() }
        val overlayButton = button("Enable floating button") { enableFloatingButton() }
        val stopButton = button("Hide floating button") {
            stopService(Intent(this, FloatingButtonService::class.java))
            status.text = "Floating button hidden."
        }

        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(status)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        outer.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        outer.addView(keyButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        outer.addView(overlayButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        outer.addView(stopButton, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        setContentView(outer)
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun setApiKey() {
        val field = EditText(this).apply {
            hint = "sk-..."
            inputType = 129 // text password
            setText(prefs.getString("api_key", "") ?: "")
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(TextView(this@MainActivity).apply {
                text = "Paste your OpenAI API key. It is stored only on this phone, but a rooted or compromised phone could expose it. API usage is billed separately."
                textSize = 14f
            })
            addView(field)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Connect GPT")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val key = field.text.toString().trim()
                prefs.edit().putString("api_key", key).apply()
                status.text = if (key.isBlank()) "No API key saved." else "API key saved on this phone."
            }.show()
    }

    private fun enableFloatingButton() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            status.text = "Allow 'Display over other apps', then return and tap Enable floating button again."
            return
        }
        startService(Intent(this, FloatingButtonService::class.java))
        status.text = "Floating button enabled. Tap the purple button on the screen edge."
    }

    private fun startSpeechRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition isn't available on this phone."
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 45)
            status.text = "Allow microphone access, then tap Speak again."
            return
        }
        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now")
        }
        try {
            startActivityForResult(recognizerIntent, 46)
        } catch (_: Exception) {
            status.text = "Couldn't open speech recognition. Check that Google speech services are installed."
        }
    }

    @Deprecated("Deprecated by Android but still works for this simple prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 46 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                transcript.text = "You: $spoken\n\nThinking..."
                askGpt(spoken)
            }
        }
    }

    private fun sendTypedMessage() {
        val message = input.text.toString().trim()
        if (message.isBlank()) return
        input.setText("")
        transcript.text = "You: $message\n\nThinking..."
        askGpt(message)
    }

    private fun askGpt(message: String) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            status.text = "First tap Set API key and add an OpenAI API key."
            transcript.text = "Your message: $message\n\nGPT isn't connected yet. Add your API key to enable replies."
            return
        }
        status.text = "Connecting to GPT..."
        executor.execute {
            try {
                val answer = OpenAiClient.reply(key, message)
                runOnUiThread {
                    transcript.text = "You: $message\n\nGPT: $answer"
                    status.text = "Ready."
                    if (speechReady) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "mom-gpt-answer")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Request failed."
                    transcript.text = "You: $message\n\nCouldn't get a GPT reply: ${e.message ?: "unknown error"}\n\nCheck your API key, internet connection, and API billing."
                }
            }
        }
    }

    override fun onInit(statusCode: Int) {
        speechReady = statusCode == TextToSpeech.SUCCESS
        if (speechReady) tts.language = Locale("en", "IN")
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        executor.shutdown()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
