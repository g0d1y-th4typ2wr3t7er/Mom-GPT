package com.example.momgpt

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object OpenAiClient {
    fun reply(apiKey: String, userMessage: String): String {
        val connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            val payload = JSONObject()
                .put("model", "gpt-4.1-mini")
                .put("instructions", "You are a kind, patient English-speaking assistant for an adult learner in India. Use simple, clear English. If the user makes an English mistake, gently offer a corrected version. Answer everyday questions safely and concisely.")
                .put("input", JSONArray().put(
                    JSONObject().put("role", "user").put("content", JSONArray().put(
                        JSONObject().put("type", "input_text").put("text", userMessage)
                    ))
                ))
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            if (code !in 200..299) {
                val message = json.optJSONObject("error")?.optString("message") ?: "HTTP $code"
                throw IllegalStateException(message)
            }
            val output = json.optJSONArray("output") ?: throw IllegalStateException("No output returned")
            val parts = mutableListOf<String>()
            for (i in 0 until output.length()) {
                val item = output.optJSONObject(i) ?: continue
                val content = item.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val part = content.optJSONObject(j) ?: continue
                    if (part.optString("type") == "output_text") {
                        val text = part.optString("text")
                        if (text.isNotBlank()) parts.add(text)
                    }
                }
            }
            return parts.joinToString("\n").ifBlank { "I couldn't find a text answer in the response." }
        } finally {
            connection.disconnect()
        }
    }
}
